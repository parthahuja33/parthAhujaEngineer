/// If set, will run it as a "test filter" like the env variable TEST.
let GRUnitTest: String? = nil

//  Test suite is an alias for test group.
 
//  A test case is an instance of a test case class with test methods.
//  A test is a id<GRTest> which represents a target and a selector.
//  A test group is a collection of tests; A collection of id<GRTest> (GRTest or GRTestGroup).
 
//  For example, if you have 2 test cases, GRTestCase1 (with some test methods) and GRTestCase2 (with some test methods), 
//  your test suite might look like:
 
// "Tests" (GRTestSuite)
//   GRTestGroup (collection of tests from GRTestCase1)
//     - (void)testA1 (GRTest with target GRTestCase1 + testA1)
//     - (void)testA2 (GRTest with target GRTestCase1 + testA2)
//   GRTestGroup (collection of tests from GRTestCase2)
//     - (void)testB1; (GRTest with target GRTestCase2 + testB1)
//     - (void)testB2; (GRTest with target GRTestCase2 + testB2)

class GRTestSuite: GRTestGroup {

    // Create test suite with test cases.
    // @param name Label to give the suite
    // @param testCases Array of init'ed test case classes
    // @param delegate Delegate

    init(name: String?, testCases: [AnyHashable]?, delegate: GRTestDelegate?) {
    }

    // Creates a suite of all tests.
    // Will load all classes that subclass from GRTestCase (or register test case class).
    // @result Suite

    class func allTests() -> GRTestSuite? {
    }

    // Create suite of tests with filter.
    // This is useful for running a single test or all tests in a single test case.

    // For example,
    // 'GHSlowTest' -- Runs all test method in GHSlowTest
    // 'GHSlowTest/testSlowA -- Only runs the test method testSlowA in GHSlowTest

    // @param testFilter Test filter
    // @result Suite


    convenience init?(testFilter: String?) {
    }

    // Create suite of tests that start with prefix.
    // @param prefix If test case class starts with the prefix; If nil or empty string, returns all tests
    // @param options Compare options

    convenience init?(prefix: String?, options: String.CompareOptions) {
    }

    // Suite for a single test/method.
    // @param testCaseClass Test case class
    // @param method Method
    // @result Suite

    convenience init?(testCaseClass: AnyClass, method: Selector) {
    }

    // Return test suite based on environment (TEST=TestFoo/foo)
    // @result Suite

    class func fromEnv() -> GRTestSuite? {
    }
}

extension GRTestSuite {
    func writeJUnitXML(toDirectory directory: String?) throws {
    }
}