import UIKit

let GRUnitTestNodeKey: String? = nil

protocol GRUnitIOSTestViewControllerDelegate: AnyObject {
    func testViewController(_ testViewController: GRUnitIOSTestViewController?, didUpdate testNode: GRTestNode?)
}

/*
 View controller for a test.
 */

class GRUnitIOSTestViewController: UIViewController {
    private(set) var test: GRTest?
    weak var runnerDelegate: GRTestRunnerDelegate?
    weak var delegate: GRUnitIOSTestViewControllerDelegate?

    func log(_ text: String?) {
    }

    func setTestNode(_ testNode: GRTestNode?, runnerDelegate: GRTestRunnerDelegate?) {
    }
}