import Foundation

/// For when you need a weak reference of an object, example: `GHWeakObject(obj) wobj = obj;`
func GRWeakObject(_ o: Any) {
    //type(of: o)
}

/// For when you need a weak reference to self, example: `GHWeakSelf wself = self;`
let GRWeakSelf = GRWeakObject(self)

let GRErrorHandler = { error in
    if let error {
        GRFail("Error: %@", error)
    }
}

protocol GRTestCase: AnyObject {
    //! Run before each test method
    func setUp()
    //! Set up async
    func setUp(_ completion: () -> ())
    //! Run after each test method
    func tearDown()
    //! Tear down async
    func tearDown(_ completion: () -> ())
}

/// The base class for a test case. 
class GRTestCase: NSObject {
    weak var logWriter: GRTestCaseLogWriter?
    private(set) var cancelling = false
    var currentTest: GRTest?

    /// Log a message, which notifies the log delegate.
    /// This is not meant to be used directly, see GRTestLog(...) macro.
    /// - Parameter message: Message to log
    func log(_ message: String?) {
    }

    /// Set test case cancelling.
    func cancel() {
    }

    /// Whether the test class should be run as a part of command line tests.
    /// By default this is NO. Subclasses can override this method to disable
    /// test classes that are problematic at the command line.
    /// - Returns: YES if this test class is disabled for command line tests
    func isCLIDisabled() -> Bool {
    }

    /// - Returns: Defaults to NO; YES if we should run this test case on the main thread (queue).
    func shouldRunOnMainThread() -> Bool {
    }

    /// Cycle run loop.
    func wait(_ timeout: TimeInterval) {
    }

    /// For the test runner.
    func tearDownForTestCase() {
    }
}
