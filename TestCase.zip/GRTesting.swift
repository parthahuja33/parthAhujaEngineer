import Foundation

// GTM_BEGIN
func isTestFixtureOfClass(_ aClass: AnyClass, _ testCaseClass: AnyClass) -> Bool {
}
// GTM_END

// Utility test for loading and running tests.
// Much of this is borrowed from GTM/UnitTesting.

class GRTesting: NSObject {
    var testCaseClassNames_: NSMutableArray /* of NSString*/?

    // The shared testing instance.
    class func sharedInstance() -> GRTesting? {
    }

    // Load all test classes that we can "see".
    // @result Array of initialized (and autoreleased) test case classes in an autoreleased array.
    func loadAllTestCases() -> [AnyHashable]? {
    }

    // Load tests from target.
    // @param testCase Test case
    // @result Array of id<GRTest>
    func loadTests(from testCase: GRTestCase?, delegate: GRTestDelegate?) -> [AnyHashable]? {
    }

    // See if class is of a registered test case class.
    // @param aClass Class
    func isTestCaseClass(_ aClass: AnyClass) -> Bool {
    }

    // Register test case class.
    // @param aClass Class
    func register(_ aClass: AnyClass) {
    }

    // Register test case class by name.
    // @param className Class name (via NSStringFromClass(aClass)
    func registerClassName(_ className: String?) {
    }

    // Format test exception.
    // @param exception Exception
    // @result Description
    class func description(for exception: NSException?) -> String? {
    }

    // Filename for cause of test exception.
    // @param test Test
    // @result Filename
    class func exceptionFilename(for test: GRTest?) -> String? {
    }

    // Line number for cause of test exception.
    // @param test Test
    // @result Line number
    class func exceptionLineNumber(for test: GRTest?) -> Int {
    }
}
