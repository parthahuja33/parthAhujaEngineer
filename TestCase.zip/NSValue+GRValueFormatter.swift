import Foundation

// SENTE_BEGIN

extension NSValue {
    func ghu_contentDescription() -> String? {
    }
}
// SENTE_END

//! @endcond