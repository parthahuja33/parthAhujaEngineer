// For backwards compatibility (see GRUnitIOSAppDelegate)

class GRUnitIPhoneAppDelegate: GRUnitIOSAppDelegate {
}