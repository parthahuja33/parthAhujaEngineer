import UIKit

/*
 Table view data source for iOS test application.
 */

class GRUnitIOSTableViewDataSource: GRTestViewModel, UITableViewDataSource {
    func node(for indexPath: IndexPath?) -> GRTestNode? {
    }

    func node(forId nodeId: String?) -> GRTestNode? {
    }

    func setSelectedForAllNodes(_ selected: Bool) {
    }
}