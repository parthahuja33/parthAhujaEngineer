import Foundation
import UIKit

/*
 Main view for iOS test application.
 */

class GRUnitIOSView: UIView {
    private(set) var searchBar: UISearchBar?
    private(set) var filterControl: UISegmentedControl?
    private(set) var tableView: UITableView?
    private(set) var statusLabel: UILabel?
}