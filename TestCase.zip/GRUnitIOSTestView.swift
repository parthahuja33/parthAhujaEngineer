import UIKit

class GRUnitIOSTestView: UIView {
    func setText(_ text: String?) {
    }

    func log(_ text: String?) {
    }
}