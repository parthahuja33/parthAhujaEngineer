// Notifies about the test run.
// Delegates can be guaranteed to be notified on the main thread.
@objc protocol GRTestRunnerDelegate: NSObjectProtocol {

    // Test run started.
    // @param runner Runner
    @objc optional func testRunnerDidStart(_ runner: GRTestRunner?)

    // Test run did start test.
    // @param runner Runner
    // @param test Test
    @objc optional func testRunner(_ runner: GRTestRunner?, didStart test: GRTest?)

    // Test run did update test.
    // @param runner Runner
    // @param test Test
    @objc optional func testRunner(_ runner: GRTestRunner?, didUpdate test: GRTest?)

    // Test run did end test.
    // @param runner Runner
    // @param test Test
    @objc optional func testRunner(_ runner: GRTestRunner?, didEnd test: GRTest?)

    // Test run did cancel.
    // @param runner Runner
    @objc optional func testRunnerDidCancel(_ runner: GRTestRunner?)

    // Test run did end.
    // @param runner Runner
    @objc optional func testRunnerDidEnd(_ runner: GRTestRunner?)

    // Test run test did log message.
    // @param runner Runner
    // @param test Test
    // @param didLog Message
    @objc optional func testRunner(_ runner: GRTestRunner?, test: GRTest?, didLog: String?)
}


//  Runs the tests.
//  Tests are run on a dispatch queue. Delegate methods are called on the main thread.
 
//  For example,
 
//     GRTestRunner *runner = [[GRTestRunner alloc] initWithTest:suite];
//     runner.delegate = self;
//     [runner run:^(id<GRTest> test) { }];

class GRTestRunner: NSObject, GRTestDelegate {
    var test: GRTest?
    weak var delegate: GRTestRunnerDelegate?
    private(set) var stats: GRTestStats?
    private(set) var running = false
    private(set) var cancelling = false
    private(set) var interval: TimeInterval = 0.0
    var dispatchQueue: DispatchQueue?
    var inParallel = false

        init(test: GRTest?) {
    }

    convenience init(for test: GRTest?) {
    }

    class func forAllTests() -> Self {
    }

    convenience init(for suite: GRTestSuite?) {
    }

    convenience init(for testClassName: String?, methodName: String?) {
    }

    class func fromEnv() -> Self {
    }

    func run(_ completion: GRTestCompletionBlock) -> Bool {
    }

    func cancel() {
    }

    func log(_ message: String?) {
    }
}