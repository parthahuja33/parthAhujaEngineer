/*
 Main view controller for the iOS test application.
 */

class GRUnitIOSViewController: UIViewController, UITableViewDelegate, GRTestRunnerDelegate, UISearchBarDelegate, GRUnitIOSTestViewControllerDelegate {
    var suite: GRTestSuite?

    func reload(_ test: GRTest?) {
    }

    func scroll(to test: GRTest?) {
    }

    func scrollToBottom() {
    }

    func setStatusText(_ message: String?) {
    }

    func runTests() {
    }

    func cancel() {
    }

    func reload() {
    }

    func loadDefaults() {
    }

    func saveDefaults() {
    }

    func dataSource() -> GRUnitIOSTableViewDataSource? {
    }
}