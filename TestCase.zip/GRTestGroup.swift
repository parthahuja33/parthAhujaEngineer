// Interface for a group of tests.
// This group conforms to the GRTest protocol as well (see Composite pattern).

protocol GRTestGroup: GRTest {
    /// Name.
    func name() -> String?
    /// Parent for test group.
    func parent() -> GRTestGroup?
    /// Children for test group.
    func children() -> [AnyHashable]?
}

//  A collection of tests (or test groups).

//  A test group is a collection of `id<GRTest>`, that may represent a set of test case methods. 
 
//  For example, if you had the following GRTestCase.

//      @interface FooTest : GRTestCase {}
//      - (void)testFoo;
//      - (void)testBar;
//      @end
 
//  The GRTestGroup would consist of and array of GRTest: FooTest#testFoo, FooTest#testBar, 
//  each test being a target and selector pair.

//  A test group may also consist of a group of groups (since GRTestGroup conforms to GRTest),
//  and this might represent a GRTestSuite.

class GRTestGroup: NSObject, GRTestDelegate, GRTestGroup {
    var interval: TimeInterval = 0.0
    var status: GRTestStatus?
    var stats: GRTestStats?
    var exception: NSException?
    var disabled = false
    var hidden = false
    weak var delegate: GRTestDelegate?
    weak var parent: GRTestGroup?
    private(set) var testCase: GRTestCase?

    // Create an empty test group.
    // @param name The name of the test group
    // @param delegate Delegate, notifies of test start and end
    // @result New test group
    init(name: String?, delegate: GRTestDelegate?) {
    }

    // Create test group from a test case.
    // @param testCase Test case
    // @param delegate Delegate, notifies of test start and end
    // @result New test group
    init(testCase: GRTestCase?, delegate: GRTestDelegate?) {
    }

    // Create test group from a single test.
    // @param testCase Test case
    // @param selector Test to run 
    // @param delegate Delegate, notifies of test start and end
    init(testCase: GRTestCase?, selector: Selector, delegate: GRTestDelegate?) {
    }

    // Create test group from a test case.
    // @param testCase Test case
    // @param delegate Delegate, notifies of test start and end
    // @result New test group
    convenience init?(fromTestCase testCase: GRTestCase?, delegate: GRTestDelegate?) {
    }

    // Add a test case (or test group) to this test group.
    // @param testCase Test case, could be a subclass of GRTestCase
    func add(_ testCase: GRTestCase?) {
    }

    // Add a test group to this test group.
    // @param testGroup Test group to add
    func add(_ testGroup: GRTestGroup?) {
    }

    // Add tests to this group.
    // @param tests Tests to add
    func addTests(_ tests: [AnyHashable]?) {
    }

    // Add test to this group.
    // @param test Test to add
    func add(_ test: GRTest?) {
    }

    // Get list of failed tests.
    // @result Failed tests
    func failedTests() -> [AnyHashable]? {
    }
}
//! @endcond