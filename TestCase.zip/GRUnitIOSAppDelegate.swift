import UIKit

/// Application delegate for the iOS test application.

@UIApplicationMain
class GRUnitIOSAppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}